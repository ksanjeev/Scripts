(*
 * This is a script to remove all files in a project that are
 * unknown to CVS.  This would be easier in a scripting language,
 * but Win32 is limited.
 *
 * ----------------------------------------------------------------
 *
 * @begin[license]
 * Copyright (C) 2003 Jason Hickey, Caltech
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * Author: Jason Hickey
 * @email{jyh@cs.caltech.edu}
 * @end[license]
 *)
open Lm_printf

open Lm_string_set

(*
 * Flags.
 *)

(* Forcably remove files *)
let rm_force = ref false

(*
 * List the entries in a directory.
 *)
let ls_aux dirname =
   let dir = Unix.opendir dirname in
   let rec collect entries =
      let entry =
      try Some (Unix.readdir dir) with
         End_of_file ->
            None
      in
         match entry with
            Some "."
          | Some ".."
          | Some "CVS" ->
               collect entries
          | Some name ->
               collect (name :: entries)
          | None ->
               entries
   in
   let entries = collect [] in
      Unix.closedir dir;
      entries

let ls dirname =
   try ls_aux dirname with
      Unix.Unix_error _ ->
         []

let ignore_files = ref (StringSet.empty)

let ignore_file name =
   ignore_files := StringSet.add !ignore_files name;
   if Filename.is_relative name then
      ignore_files := StringSet.add !ignore_files (Filename.concat Filename.current_dir_name name)

(*
 * Get the entries in a CVS/Entries file.
 *)
let cvs_entries_aux dirname =
   let filename = dirname ^ "/CVS/Entries" in
   let inx = open_in_bin filename in
   let rec collect_entries files dirs =
      let line =
         try Some (input_line inx) with
            End_of_file ->
               None
      in
         match line with
            None ->
               files, dirs
          | Some line ->
               match Lm_string_util.split "/" line with
                  "D" :: name :: _ ->
                     let dirs = StringSet.add dirs name in
                        collect_entries files dirs
                | "" :: name :: _ ->
                     let files = StringSet.add files name in
                        collect_entries files dirs
                | _ ->
                     collect_entries files dirs
   in
   let files, dirs = collect_entries StringSet.empty StringSet.empty in
      close_in inx;
      files, dirs

let cvs_entries dirname =
   try cvs_entries_aux dirname with
      Sys_error _ ->
         StringSet.empty, StringSet.empty

(*
 * Arguments.
 *)
let args = [
   "-f", Arg.Set rm_force, "\tDo not ask whether to remove files";
   "-i", Arg.String ignore_file, "<file>\tIgnore the file";
]

let root_dirs = ref []

let add_dir s =
   root_dirs := s :: !root_dirs

(*
 * Main program starts from the current directory.
 *)
let main () =
   let rm_command =
      match Sys.os_type with
         "Win32" ->
            if !rm_force then
               "del /F "
            else
               "del /P "
       | "Unix"
       | "Cygwin" ->
            if !rm_force then
               "/bin/rm -rf "
            else
               "/bin/rm -ri "
       | s ->
            raise (Failure ("cvs_realclean: unknown architecture " ^ s))
   in
   (*
    * Remove a file/directory.
    *)
   let rm dirname name =
      let name = Filename.concat dirname name in
         if not (StringSet.mem !ignore_files name) then begin
            printf "removing %s...@." name;
            ignore (Unix.system (rm_command ^ (Filename.quote name)))
         end
   in
   (*
    * Remove all entries that are not known to CVS.
    *)
   let rec clean dirname =
      let files, dirs = cvs_entries dirname in
      let names = ls dirname in
      let subdirs =
         List.fold_left (fun subdirs name ->
               if StringSet.mem files name then
                  subdirs
               else if StringSet.mem dirs name then
                  Filename.concat dirname name :: subdirs
               else
                  begin
                     rm dirname name;
                     subdirs
                  end) [] names
      in
         List.iter clean subdirs
   in
   let dirs =
      match !root_dirs with
         [] -> [Filename.current_dir_name]
       | l -> List.rev l
   in
      List.iter clean dirs

let _ =
   Arg.parse args add_dir "cvs_realclean removes all files not known by CVS.\nUsage: cvs_realclean <options> [dir1 [dir2 ...]]\nOptions are:";
   Printexc.catch main ()

(*!
 * @docoff
 *
 * -*-
 * Local Variables:
 * Caml-master: "compile"
 * End:
 * -*-
 *)
